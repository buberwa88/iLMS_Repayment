<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
?>

<?=

DetailView::widget([
    'model' => $model,
    'attributes' => [
        [
            'attribute' => 'name',
            'value' => $model->applicant->user->firstname . '  ' . $model->applicant->user->middlename . ' ' . $model->applicant->user->surname
        ],
        ['attribute' => 'f4indexno',
            'value' => $model->applicant->f4indexno
        ],
        ['attribute' => 'NID',
            'value' => $model->applicant->NID
        ],
        [
            'attribute' => 'sex',
            'value' => $model->applicant->sex == 'M' ? 'Male' : 'Female'
        ],
        [
            'attribute' => 'date_of_birth',
            'value' => $model->applicant->date_of_birth ? Date('d, D-M-Y', strtotime($model->applicant->date_of_birth)) : ''
        ],
        ['attribute' => 'phone_number',
            'value' => $model->applicant->user->phone_number
        ],
        [
            'attribute' => 'loan_confirmation_status',
            'label' => 'Total Loan Status',
            'value' => strtoupper(common\models\LoanBeneficiary::getLoanConfirmationStatusNameByApplicantID($model->applicant->applicant_id))
        ],
        ['attribute' => 'liquidation_letter_status',
            'label' => 'Liquidation Letter',
            'value' => common\models\LoanBeneficiary::getLiqudationStatusNameByApplicantID($model->applicant->applicant_id),
            'visible' => $data->liquidation_letter_status == common\models\LoanBeneficiary::LOAN_LIQUIDATION_ISSUED ? TRUE : FALSE,
        ],
        [
            'attribute' => 'applicant_id',
            'label' => 'Beneficiary/ Non-Beneficiary?',
//            'width' => '300px',
            'format' => 'raw',
            'value' => strtoupper(backend\modules\repayment\models\LoanNonBeneficiary::isNonBeneficiary($model->applicant->applicant_id) == TRUE ? '<span class=" green"; style="color:green;">Non-Beneficiary</span>' :'')
        ],
//      
    ],
]);
?>  



