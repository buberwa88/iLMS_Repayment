<?php
use yii\helpers\Html;
?>
<?= Html::cssFile("@web/css/operationsPrint.css"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
</head>
<div class="contents-panel">
<body>
<table border="1" width="100%">
   <thead>
    <tr>
     <th style="width:100%">page header</th>
   </tr>
   <tr>
    <th><hr style="color:#000080"/></th>
   </tr>
  </thead> 
  <tfoot>
   <tr>
    <td width="100%">
     <table width="100%" border="0">
       <tr>
         <td colspan="4"><br>&nbsp;</td>
      </tr>
    </table>
	
  </tfoot>
  <tbody>
    <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
   <tr>
      <td width="100%">
         put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
		 
		 <br/>
		 
		 put your text (for example article main body, title etc...)
		 ewfewfewfewg
		 5h56
		 6565
		 65j67itnr67j77ik67k
		 67j76k78kk6
		 65ju67j67j
		 
		 
		 56u6hr5y
		 567
      </td>
   </tr>
 </tbody>
</table>
<table id="footer" width="100%">
  <tr>
    <td width="100%">
      footer text
    </td>
  </tr>
</table>
</body>
	</div>
	
</html>
<?php ?>