
<div class="employed-beneficiary-view">
    <?php
    foreach ($dataProviderBeneficiaryDisbursmentTypes as $disbursements) {
        ?>
        <h4><b>Loan #<?php echo $disbursements->application_id ?></b></h4>
        <?php
        $loan_given_to = \frontend\modules\repayment\models\LoanRepaymentDetail::LOAN_GIVEN_TO_LOANEE;

        echo $this->render('_application_loan_summary', ['application' => $applications, 'model' => $model,'loan_given_to'=>$loan_given_to]);
    }
    ?>
</div>
