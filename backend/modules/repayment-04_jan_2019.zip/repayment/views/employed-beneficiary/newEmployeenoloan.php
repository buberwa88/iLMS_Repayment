<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $searchModel frontend\modules\repayment\models\EmployedBeneficiarySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Non Beneficiaries(Employees with no loan)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="employed-beneficiary-index">

    <div class="panel panel-info">
        <div class="panel-heading">
            <?= Html::encode($this->title) ?>
        </div>
        <div class="panel-body">
            <?php if ($totalUnverifiedEmployees > 0) { ?>
                <p>        
                    <?= Html::beginForm(['employed-beneficiary/confirmed-employeesbeneficiaries'], 'post'); ?>
                    <?= Html::submitButton('Confirm selected employees as beneficiaries', ['class' => 'btn btn-success',]); ?>

                </p>
            <?php } ?>


            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
//                    [
//                        'class' => 'kartik\grid\ExpandRowColumn',
//                        'value' => function ($model, $key, $index, $column) {
//                            return GridView::ROW_COLLAPSED;
//                        },
//                        'allowBatchToggle' => true,
//                        'detail' => function ($model) {
//                            return $this->render('view', ['model' => $model]);
//                        },
//                                'detailOptions' => [
//                                    'class' => 'kv-state-enable',
//                                ],
//                            ],
                    [
                        'attribute' => 'employerName',
                        'label' => "Employer",
                        'value' => function ($model) {
                            return $model->employer->employer_name;
                        },
                    ],
                    [
                        'attribute' => 'firstname',
                        'label' => "First Name",
                        //'vAlign' => 'middle',
                        'value' => function ($model) {
                            return Html::a($model->applicant->user->firstname, ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                        },
                                'format' => 'raw',
                            ],
                            [
                                'attribute' => 'middlename',
                                'label' => "Middle Name",
                                'value' => function ($model) {
                                    return Html::a($model->applicant->user->middlename, ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                                },
                                        'format' => 'raw',
                                    ],
                                    [
                                        'attribute' => 'surname',
                                        'label' => "Last Name",
                                        'value' => function ($model) {
                                            return Html::a($model->applicant->user->surname, ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                                        },
                                                'format' => 'raw',
                                            ],
                                            [
                                                'attribute' => 'f4indexno',
                                                'label' => "Index Number",
                                                'value' => function ($model) {
                                                    return Html::a($model->f4indexno, ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                                                },
                                                        'format' => 'raw',
                                                    ],
                                                    [
                                                        'attribute' => 'totalLoan',
                                                        'hAlign' => 'right',
                                                        'format' => ['decimal', 2],
                                                        'value' => function ($model) {
                                                    return Html::a(backend\modules\repayment\models\LoanSummaryDetail::getTotalLoanBeneficiaryOriginal($model->applicant_id, date('Y-m-d', time()), \frontend\modules\repayment\models\LoanRepaymentDetail::LOAN_GIVEN_TO_LOANEE), ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                                                },
                                                        'format' => 'raw',
                                                    ],
                                                    [
                                                        'attribute' => 'basic_salary',
                                                        //'label' => "Basic Salary",
                                                        'hAlign' => 'right',
                                                        'format' => ['decimal', 2],
                                                        'value' => function ($model) {
                                                    return Html::a($model->basic_salary, ['/repayment/loan-beneficiary/view-loanee-details', 'id' => $model->applicant_id]);
                                                },
                                                        'format' => 'raw',
                                                    ],
                                                    ['class' => 'yii\grid\CheckboxColumn'],
                                                ],
                                            ]);
                                            ?>
                                            <?php if ($totalUnverifiedEmployees > 0) { ?>
                                                <?= Html::endForm(); ?>
                                            <?php } ?>
        </div>
    </div>
</div>
